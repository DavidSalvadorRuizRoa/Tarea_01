
//MAIN//

import java.util.Scanner;

public class Tarea1 {
    
    public static void main(String[] args){
        
        System.out.println("Tarea 1");
        System.out.println("Nombre : David Salvador Ruiz Roa");
        System.out.println("Matrícula: A01377556 \n");
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Teclea tu día de nacimiento:" );
        int dia = teclado.nextInt();
        
        System.out.println("Teclea tu mes de nacimiento:" );
        int mes = teclado.nextInt();
        
        System.out.println("Teclea tu año de nacimiento:" );
        int año = teclado.nextInt();
        
        Fecha fechaUsuario = new Fecha(dia, mes, año);
        
        System.out.println("Teclea tu nombre:" );
        String nombre = teclado.next() + " " + teclado.next();
        
        FrecuenciaCardiaca frecuenciaUsuario = new FrecuenciaCardiaca(nombre, fechaUsuario);
        double frecuenciaCardiaca = frecuenciaUsuario.getMaximaFrecuenciaCardiaca();
        
        System.out.println(" ");
        System.out.println("Nombre: " + nombre);
        System.out.println("Fecha de Nacimiento: " + fechaUsuario);
        System.out.println("Edad: " + fechaUsuario.calcularEdad());
        System.out.println("Frecuencia cardiaca máxima: " + frecuenciaCardiaca);
        System.out.println("Frecuencia recomendada:" + "[" + (frecuenciaCardiaca*.5) + "," + (frecuenciaCardiaca*.85) + "]" );
    }
    
}
