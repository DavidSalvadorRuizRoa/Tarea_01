
import java.util.Calendar;

public class Fecha {
    //Variables de instancia
    private int dia;
    private int mes;
    private int año;
    
    public Fecha(int dia,int mes,int año){
        //Constructor que altera las variables
        this.dia = dia;
        this.mes = mes;
        this.año = año;
        
    }    
    public String toString(){
        //Genera la fecha en el formato
        String fechaFormato =  dia + "/" + mes + "/" + año ;
        return fechaFormato;
    }
    public int calcularEdad(){
        //Calcula la edad de la persona
        int añoActual = Calendar.getInstance().get(Calendar.YEAR);
        int mesActual = Calendar.getInstance().get(Calendar.MONTH) + 1;
        int diaActual = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
    
        int añoEdad = añoActual - año;
        
        
        if (mesActual < mes){
            añoEdad = añoEdad - 1;
        }
        
        if(mesActual == mes && diaActual < dia ){
            añoEdad = añoEdad -1;
        }
        return añoEdad;
    }
    
}
