public class FrecuenciaCardiaca {
    //Variables de instancia
    private String nombre;
    private Fecha fechaNacimiento;
    
    public FrecuenciaCardiaca(){
        //Se asigna un valor inicial por medio de un constructor
        nombre = "";
    }
    
    public FrecuenciaCardiaca(String nombre, Fecha fecha){
        //Se le reasignan los valores de las variables de instancia
        this.nombre = nombre;
        this.fechaNacimiento = fecha;
    }
    
    public double getMaximaFrecuenciaCardiaca(){
        //Se hace la operación para tener la frecuencia
        double frecuencia = 0;
        frecuencia = 220 - fechaNacimiento.calcularEdad();
        return frecuencia;
    }
    
    public String getNombre(){
        //Método que regresa el nombre
        return nombre;
    }
    public Fecha getFechaNacimiento(){
        //Método que regresa la Fecha de nacimiento
        return fechaNacimiento;
    }
    public void setNombre(String nombre){
        //Método que le asigna el nombre al nombre
        this.nombre = nombre;
    }
    public void setFecha(Fecha fecha){
        //Método que le asigna la fecha a fechaNacimiento
        this.fechaNacimiento = fecha;
    }
}
